show tables from sqlproject;
use sqlproject;
 CREATE TABLE route_details As (select Route_id, Flight_num, Origin_airport, 
Destination_airport, Aircraft_id, Distance_miles from routes);
SELECT DISTINCT c.customer_id, c.first_name, c.last_name FROM passengers_on_flights p JOIN customer c ON p.customer_id = c.customer_id WHERE p.route_id BETWEEN '01' AND '25';
SELECT COUNT(*) AS total_passengers, SUM(price_per_ticket) AS total_revenue FROM ticket_details WHERE class_id = 'business';
SELECT CONCAT(first_name, ' ', last_name) AS full_name FROM customer;
SELECT c.*
FROM customer c
JOIN ticket_details t ON c.customer_id = t.customer_id;
SELECT c.first_name, c.last_name
FROM customer c
JOIN ticket_details t ON c.customer_id = t.customer_id
WHERE t.brand = 'Emirates';

SELECT customer_id
FROM passengers_on_flights
WHERE class_id = 'Economy Plus'
GROUP BY customer_id
HAVING COUNT(*) > 0;

SELECT *, IF(SUM(price_per_ticket) > 10000, 'Yes', 'No') AS revenue_crossed_10000
FROM ticket_details
GROUP BY customer_id;

CREATE USER 'new_user'@'localhost' IDENTIFIED BY 'password';
GRANT ALL PRIVILEGES ON database_name.* TO 'new_user'@'localhost';
FLUSH PRIVILEGES;

SELECT class_id, price_per_ticket,
       MAX(price_per_ticket) OVER (PARTITION BY class_id) AS max_ticket_price
FROM ticket_details;

SELECT *
FROM passengers_on_flights
WHERE route_id = 4;

EXPLAIN SELECT *
FROM passengers_on_flights
WHERE route_id = 4;

SELECT customer_id, aircraft_id, SUM(price_per_ticket) AS total_price
FROM ticket_details
GROUP BY customer_id, aircraft_id WITH ROLLUP;

CREATE VIEW business_class_customers AS
SELECT c.customer_id, c.first_name, c.last_name, t.brand
FROM customer c
JOIN ticket_details t ON c.customer_id = t.customer_id
WHERE t.class_id = 'business';


DELIMITER //

CREATE PROCEDURE GetPassengerDetailsByRouteRange(IN start_route_id INT, IN end_route_id INT)
BEGIN
    IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema = 'your_database_name' AND table_name = 'passengers_on_flights') THEN
        SELECT *
        FROM passengers_on_flights
        WHERE route_id BETWEEN start_route_id AND end_route_id;
    ELSE
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'The table passengers_on_flights does not exist.';
    END IF;
END //

DELIMITER ;


DELIMITER //

CREATE PROCEDURE GetRoutesWithDistanceMoreThan2000()
BEGIN
    SELECT *
    FROM routes
    WHERE Distance_miles > 2000;
END //

DELIMITER ;


DELIMITER //

CREATE PROCEDURE GroupDistanceByCategory()
BEGIN
    SELECT *,
        CASE
            WHEN Distance_miles <= 2000 THEN 'SDT'
            WHEN Distance_miles > 2000 AND Distance_miles <= 6500 THEN 'IDT'
            WHEN Distance_miles > 6500 THEN 'LDT'
        END AS distance_category
    FROM routes;
END //

DELIMITER ;

DELIMITER //

CREATE FUNCTION IsComplimentaryServiceProvided(class_id VARCHAR(10)) RETURNS VARCHAR(3)
BEGIN
    DECLARE is_complimentary VARCHAR(3);
    
    IF class_id IN ('Business', 'Economy Plus') THEN
        SET is_complimentary = 'Yes';
    ELSE
        SET is_complimentary = 'No';
    END IF;
    
    RETURN is_complimentary;
END //

CREATE PROCEDURE GetTicketDetailsWithComplimentaryService()
BEGIN
    SELECT p_date, customer_id, class_id, IsComplimentaryServiceProvided(class_id) AS complimentary_service
    FROM ticket_details;
END //

DELIMITER ;

